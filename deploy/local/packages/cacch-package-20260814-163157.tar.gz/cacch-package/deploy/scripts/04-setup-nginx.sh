#!/usr/bin/env bash
# ============================================================
# 04-setup-nginx.sh - Nginx 配置安装（幂等）
# 功能：安装站点配置、移除默认站点、测试并重载 Nginx
# 用法：sudo bash 04-setup-nginx.sh
# ============================================================
set -euo pipefail

APP_DIR="/home/aidoc/cacch-ai-platform"
SRC_CONF="$APP_DIR/deploy/config/nginx-cacch.conf"
AVAILABLE="/etc/nginx/sites-available/cacch-ai"
ENABLED="/etc/nginx/sites-enabled/cacch-ai"

if [[ $EUID -ne 0 ]]; then
    echo "[ERROR] 请使用 root 执行：sudo bash $0"
    exit 1
fi

if [[ ! -f "$SRC_CONF" ]]; then
    echo "[ERROR] 未找到 $SRC_CONF"
    echo "        请确认项目代码已上传到 $APP_DIR"
    exit 1
fi

echo "==> [1/4] 安装站点配置"
cp "$SRC_CONF" "$AVAILABLE"
ln -sf "$AVAILABLE" "$ENABLED"

echo "==> [2/4] 移除默认站点（避免 80 端口冲突）"
rm -f /etc/nginx/sites-enabled/default

echo "==> [3/4] 检查前端目录存在"
if [[ ! -f "$APP_DIR/frontend-dist/index.html" ]]; then
    echo "    [WARN] frontend-dist 尚无 index.html，请先执行 03-deploy-frontend.sh"
fi

echo "==> [4/4] 测试并重载 Nginx"
if nginx -t; then
    systemctl enable nginx
    systemctl restart nginx
    echo "    [OK] Nginx 已重载"
else
    echo "    [ERROR] Nginx 配置测试失败，请检查 $AVAILABLE"
    exit 1
fi

echo ""
echo "[OK] Nginx 配置完成"
echo "    访问: http://10.80.85.85  （前端页面）"
echo "    API:  http://10.80.85.85/api/v1/health"
