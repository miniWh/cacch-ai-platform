#!/usr/bin/env bash
# ============================================================
# 01-init-server.sh - 服务器环境初始化（幂等）
# 功能：安装 Python 3.12、venv、pip、Nginx，创建目录结构
# 适用：Ubuntu 22.04 / 24.04 (2C4G)
# 用法：sudo bash 01-init-server.sh
# ============================================================
set -euo pipefail

APP_USER="aidoc"
APP_DIR="/home/aidoc/cacch-ai-platform"

# --- 检查 root ---
if [[ $EUID -ne 0 ]]; then
    echo "[ERROR] 请使用 root 执行：sudo bash $0"
    exit 1
fi

echo "==> [1/5] 更新 apt 软件源"
export DEBIAN_FRONTEND=noninteractive
apt-get update -y

echo "==> [2/5] 检查 Python 版本"
PY_OK=0
# 优先使用 python3.12（deadsnakes 安装后 python3 可能仍是系统旧版本）
if command -v python3.12 >/dev/null 2>&1; then
    PY_OK=1
    PYTHON_BIN="python3.12"
    echo "    发现 python3.12，直接使用"
elif command -v python3 >/dev/null 2>&1; then
    PY_VER=$(python3 -c 'import sys; print(f"{sys.version_info.major}.{sys.version_info.minor}")')
    echo "    当前 python3: $PY_VER"
    major=${PY_VER%%.*}
    minor=${PY_VER##*.}
    if [[ $major -ge 3 && $minor -ge 12 ]]; then
        PY_OK=1
        PYTHON_BIN="python3"
    fi
fi

if [[ $PY_OK -eq 0 ]]; then
    echo "    Python < 3.12，通过 deadsnakes PPA 安装 python3.12 ..."
    apt-get install -y software-properties-common
    add-apt-repository -y ppa:deadsnakes/ppa
    apt-get update -y
    apt-get install -y python3.12 python3.12-venv python3.12-dev
    PYTHON_BIN="python3.12"
else
    PYTHON_BIN="python3"
fi
echo "    使用解释器: $PYTHON_BIN"

echo "==> [3/5] 安装依赖（venv / pip / nginx / 基础工具）"
apt-get install -y \
    "$PYTHON_BIN"-venv \
    "$PYTHON_BIN"-pip \
    nginx \
    curl \
    git \
    build-essential \
    libpq-dev

echo "==> [4/5] 创建应用目录结构"
mkdir -p "$APP_DIR"/{logs,data/crawl,frontend-dist,deploy}
chown -R "$APP_USER":"$APP_USER" "$APP_DIR"

echo "==> [5/5] 确认 nginx 与 python 版本"
nginx -v 2>&1 || true
"$PYTHON_BIN" --version

echo ""
echo "[OK] 环境初始化完成。下一步：bash 02-deploy-backend.sh"
